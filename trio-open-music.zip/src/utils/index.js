const mapDBToModel = ({
    id,
    name,
    owner,
}) =>({
    id,
    name,
    owner,
});
module.exports = mapDBToModel;